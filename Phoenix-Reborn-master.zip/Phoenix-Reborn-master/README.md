# TitaniumPhoenix

A beautiful and lightweight web-proxy site built to be easy to use and modify for everyone.

Initial Release Date: 02/11/2019.
#### Basic info

This web-app, measuring about 14.2 MB, is designed to be as light on server storage as possible.

# Features

#### Locally Stored and Hosted Proxy Server

This allows your PhoenixHub site to have a proxy already equipped when you deploy it so you can quickly get to circumventing censorship!

#### Games

This site has links to many games on a JSCDN for quick and efficient access.

#### Chatboxes

Chatboxes for TitaniumNetwork's Services. Replace if needed.

#### Suggest Some Stuff!

Email me at titaniumnetwork.official@gmail.com if you have suggestions!

#
Property of TitaniumNetwork. You have permission to modify, however we require that you leave it open-source AND to credit us since many components of TitaniumPhoenix are open-source.
